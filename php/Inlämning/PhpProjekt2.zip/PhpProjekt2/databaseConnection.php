<?php

//$server=`83.168.227.23`;
//$user="u1164707_IvanL";
//$password="m3@kA/I0Ky";
//$database = "db1164707_IvanL";


try {
    
    $conn = new PDO('mysql:host=83.168.227.23; dbname=db1164707_IvanL', 'u1164707_IvanL', 'm3@kA/I0Ky');
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    
    echo $e->getMessage();
    
    die();
    
}



?>